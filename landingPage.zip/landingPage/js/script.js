// ============================================================
// MOBILE NAVIGATION TOGGLE
// ============================================================
const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.nav');

if (navToggle) {
    navToggle.addEventListener('click', () => {
        // Toggle 'active' class on both the button and the nav menu
        navToggle.classList.toggle('active');
        nav.classList.toggle('active');

        // Accessibility: Tell screen readers if the menu is open or closed
        const isOpen = nav.classList.contains('active');
        navToggle.setAttribute('aria-expanded', isOpen);
    });
}

// ============================================================
// CLOSE NAV MENU WHEN A LINK IS CLICKED (Mobile UX)
// ============================================================
const navLinks = document.querySelectorAll('.nav__link');

navLinks.forEach(link => {
    link.addEventListener('click', () => {
        // If the menu is open, close it
        if (nav.classList.contains('active')) {
            navToggle.classList.remove('active');
            nav.classList.remove('active');
            navToggle.setAttribute('aria-expanded', 'false');
        }
    });
});

// ============================================================
// SMOOTH SCROLL FOR ANCHOR LINKS (Fallback for older browsers)
// ============================================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        // Only run if it's a valid internal link (not just "#")
        if (href !== '#') {
            const targetElement = document.querySelector(href);
            if (targetElement) {
                e.preventDefault();
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        }
    });
});